"""Compare ORM entities and column rows against one unchanged synthetic history snapshot."""

import asyncio
import cProfile
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import pstats
import subprocess
import sys
import time
from contextlib import aclosing
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from agent_runtime import Message, TextContent
from agent_runtime.context import ContextWindow
from agent_runtime.memory.postgres import PostgresMemoryStore

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "build/stage-e-row-profile"
OUTPUT.mkdir(exist_ok=True)
REVISION = "2e38c0018c2dd348a26e5a386cdb897c463c5c4c"
old = subprocess.check_output(
    [
        "git",
        "-c",
        "safe.directory=F:/ChatGPT/agent-runtime-kit",
        "show",
        REVISION + ":src/agent_runtime/memory/postgres.py",
    ],
    cwd=ROOT,
)
(OUTPUT / "orm_postgres.py").write_bytes(old)
new = (ROOT / "src/agent_runtime/memory/postgres.py").read_bytes()
(OUTPUT / "columns_postgres.py").write_bytes(new)
spec = importlib.util.spec_from_file_location("orm_postgres", OUTPUT / "orm_postgres.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


async def main():
    engine = create_async_engine(
        os.environ["AGENT_RUNTIME_TEST_DATABASE_URL"], pool_size=2, max_overflow=0
    )
    report = {
        "purpose": "separate diagnostic source experiment, not final wheel acceptance",
        "old_revision": REVISION,
        "old_source_sha256": hashlib.sha256(old).hexdigest(),
        "new_source_sha256": hashlib.sha256(new).hexdigest(),
        "python": sys.version,
        "packages": {
            name: importlib.metadata.version(name)
            for name in ["sqlalchemy", "psycopg", "pydantic", "agent-runtime-kit"]
        },
        "samples": [],
        "profiles": {},
    }
    try:
        async with engine.connect() as conn:
            thread = await conn.scalar(
                text(
                    "SELECT t.id FROM agent_threads t WHERE t.namespace LIKE 'history-workload-%' "
                    "AND EXISTS (SELECT 1 FROM agent_messages m WHERE m.thread_id=t.id "
                    "AND m.sequence=40000) ORDER BY t.created_at DESC LIMIT 1"
                )
            )
            assert thread is not None
            count = await conn.scalar(
                text("SELECT count(*) FROM agent_messages WHERE thread_id=:id"), {"id": thread}
            )
        report["history_rows"] = count
        stores = {"orm": module.PostgresMemoryStore(engine), "columns": PostgresMemoryStore(engine)}
        current = [Message(role="user", content=[TextContent(text="row profile")])]
        window = ContextWindow(65536)
        reference = None

        async def consume(name):
            async with aclosing(stores[name].stream_messages(thread)) as source:

                async def messages():
                    async for item in source:
                        yield item.message

                selection = await window.select_stream(messages(), current)
            assert selection.history_messages == count
            assert engine.pool.checkedout() == 0
            return selection

        for repetition in range(3):
            for name in ["orm", "columns"] if repetition % 2 == 0 else ["columns", "orm"]:
                started = time.perf_counter()
                result = await consume(name)
                elapsed = time.perf_counter() - started
                if reference is None:
                    reference = result
                assert result == reference
                report["samples"].append(
                    {"mode": name, "repetition": repetition, "seconds": elapsed}
                )
        for name in stores:
            profile = cProfile.Profile()
            profile.enable()
            assert await consume(name) == reference
            profile.disable()
            stats = pstats.Stats(profile).stats
            rows = [
                {
                    "file": Path(key[0]).name,
                    "line": key[1],
                    "function": key[2],
                    "calls": value[1],
                    "self_seconds": value[2],
                    "cumulative_seconds": value[3],
                }
                for key, value in stats.items()
            ]
            report["profiles"][name] = {
                "self": sorted(rows, key=lambda x: x["self_seconds"], reverse=True)[:40],
                "cumulative": sorted(rows, key=lambda x: x["cumulative_seconds"], reverse=True)[
                    :40
                ],
            }
        report["identical_selection"] = True
        report["checked_out_connections"] = engine.pool.checkedout()
    finally:
        await engine.dispose()
    (OUTPUT / "profile.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "profiles"}))


if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())
